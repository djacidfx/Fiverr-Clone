<?php
$db_config = array(
	'host' => 'localhost',
	'user' => 'root',
	'pass' => 'root',
	'name' => 'microncer-5'
);